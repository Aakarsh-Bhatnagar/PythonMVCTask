from flask import Blueprint
from flask import jsonify
from flask import request
from controller import controllerclass

bp = Blueprint(__name__,"mongo")
controllerobject = controllerclass()

@bp.route('/insert', methods=['POST'])
def insert():
    data=request.get_json()
    username=data['username']
    address=data['address']
    database = controllerobject.insert(username,address)
    return jsonify(database)

@bp.route('/delete', methods=['POST'])
def delete():
    data=request.get_json()
    username=data['username'] 
    database=controllerobject.delete(username)
    return jsonify(database)

@bp.route('/update',methods=['POST'])
def update():
    data=request.get_json()
    username=data['username']
    updatedaddress=data['updatedaddress']
    database=controllerobject.update(username,updatedaddress)
    return jsonify(database)