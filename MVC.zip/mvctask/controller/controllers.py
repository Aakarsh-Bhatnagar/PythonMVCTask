import model


class controllerclass(object):
    
    def insert(self, username, address):
        employee={
            'username': username,
            'address': address
        }
        result=self.check(username)
        if(result==0):
            model.employees.insert_one(employee)
            dbcontents=self.show_db()
            return dbcontents
        else:
            return "Duplicate values of username"
       


    def delete(self,username):
        result=self.check(username)
        if(result==1):
            model.employees.delete_one({"username":username})
            dbcontents=self.show_db()
            return dbcontents
        else:
            return "user not found in the database"
        
       

    def check(self,username):
        results= model.employees.count_documents({
            'username': username
        })
        if(results>0):
            return 1
        else:
            return 0
    

    def show_db(self):
        items = []
        employess=model.employees.find({},{'_id':0,'username':1,'address':1})
        for emp in employess:
            items.append(emp)
        return items


    def update(self,username,updatedaddress):
        result=self.check(username)
        if(result==1):
            model.employees.update_one( 
            {"username":username}, 
            { 
                    "$set":{
                            "address":updatedaddress
                            }
                      
                    } 
            )
            dbcontents=self.show_db()
            return dbcontents
        else:
            return "Username not found in the database"
    