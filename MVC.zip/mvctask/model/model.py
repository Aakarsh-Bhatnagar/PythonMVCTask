from pymongo import MongoClient
conn= MongoClient()
db= conn['mvc-database']
employees= db.employees